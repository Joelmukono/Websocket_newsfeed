# Python_Flask_Websocket_newsfeed
Realtime newsfeed with flask websockets.
download python_flask

download python 3.5 or later
cd to websocket_newsfeed
open terminal and run 'python3 
server.py'
navigate to http://127.0.0.1:5000/
in two different browser windows
